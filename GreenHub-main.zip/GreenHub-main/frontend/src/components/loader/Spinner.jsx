import React from "react";

function Spinner() {
  return <span className="loading loading-dots loading-sm"></span>;
}

export default Spinner;
