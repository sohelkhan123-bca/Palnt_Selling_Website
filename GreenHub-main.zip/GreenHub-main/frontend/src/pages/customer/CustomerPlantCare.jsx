import React from "react";
import PlantCareBrowse from "../../components/page/plantCare/PlantCareBrowse";

function CustomerPlantCare() {
  return (
    <div>
      <PlantCareBrowse redirectBasePath="/customer/plantcare" />
    </div>
  );
}

export default CustomerPlantCare;
