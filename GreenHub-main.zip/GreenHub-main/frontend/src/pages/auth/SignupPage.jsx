import React from "react";
import SignupComponent from "../../components/page/signup/SignupComponent";

function SignupPage() {
  return (
    <div>
      <SignupComponent />
    </div>
  );
}

export default SignupPage;
