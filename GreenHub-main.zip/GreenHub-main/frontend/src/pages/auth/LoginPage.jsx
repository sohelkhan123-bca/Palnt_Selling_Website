import React from "react";
import LoginComponent from "../../components/page/Login/LoginComponent";

function LoginPage() {
  return (
    <div>
      <LoginComponent />
    </div>
  );
}

export default LoginPage;
