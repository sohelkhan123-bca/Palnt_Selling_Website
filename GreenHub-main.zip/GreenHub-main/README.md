add .env file in backend folder
